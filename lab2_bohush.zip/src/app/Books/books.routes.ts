import { Routes } from '@angular/router';
import { BookCenterComponent } from './book-center/book-center';
import { BookListComponent } from './book-list/book-list';
import { BookDetailsComponent } from './book-details/book-details';

export const booksRoutes: Routes = [
  {
    path: '', // Базовый путь
    component: BookCenterComponent, // При открытии отображается BookCenter
    children: [
      { path: '', component: BookListComponent }, // Дочерним подгружается BookList
      { path: 'book/:id', component: BookDetailsComponent } // При выборе книги подгружается BookDetails
    ]
  }
];